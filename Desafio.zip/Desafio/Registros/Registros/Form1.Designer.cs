﻿namespace Registros
{
    partial class crud_rastreadores
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Rastrador = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMOD = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtIMEI = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtICCID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.btnMos = new System.Windows.Forms.Button();
            this.btnEd = new System.Windows.Forms.Button();
            this.btnExc = new System.Windows.Forms.Button();
            this.btnCons = new System.Windows.Forms.Button();
            this.btnCad = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgv2 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDESC = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtIDM = new System.Windows.Forms.TextBox();
            this.Rastrador.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            this.SuspendLayout();
            // 
            // Rastrador
            // 
            this.Rastrador.Controls.Add(this.tabPage1);
            this.Rastrador.Controls.Add(this.tabPage2);
            this.Rastrador.Location = new System.Drawing.Point(2, -1);
            this.Rastrador.Name = "Rastrador";
            this.Rastrador.SelectedIndex = 0;
            this.Rastrador.Size = new System.Drawing.Size(642, 354);
            this.Rastrador.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightBlue;
            this.tabPage1.Controls.Add(this.dgv1);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtMOD);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtIMEI);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtICCID);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtID);
            this.tabPage1.Controls.Add(this.btnMos);
            this.tabPage1.Controls.Add(this.btnEd);
            this.tabPage1.Controls.Add(this.btnExc);
            this.tabPage1.Controls.Add(this.btnCons);
            this.tabPage1.Controls.Add(this.btnCad);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(634, 328);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Rastreadores";
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToDeleteRows = false;
            this.dgv1.AllowUserToResizeColumns = false;
            this.dgv1.AllowUserToResizeRows = false;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Location = new System.Drawing.Point(94, 153);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(440, 150);
            this.dgv1.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(502, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Modelo";
            // 
            // txtMOD
            // 
            this.txtMOD.Location = new System.Drawing.Point(502, 37);
            this.txtMOD.Name = "txtMOD";
            this.txtMOD.Size = new System.Drawing.Size(89, 20);
            this.txtMOD.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(348, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "IMEI";
            // 
            // txtIMEI
            // 
            this.txtIMEI.Location = new System.Drawing.Point(348, 37);
            this.txtIMEI.Name = "txtIMEI";
            this.txtIMEI.Size = new System.Drawing.Size(89, 20);
            this.txtIMEI.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(196, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "ICCID";
            // 
            // txtICCID
            // 
            this.txtICCID.Location = new System.Drawing.Point(196, 37);
            this.txtICCID.Name = "txtICCID";
            this.txtICCID.Size = new System.Drawing.Size(89, 20);
            this.txtICCID.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "ID";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(40, 37);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(89, 20);
            this.txtID.TabIndex = 13;
            // 
            // btnMos
            // 
            this.btnMos.Location = new System.Drawing.Point(506, 99);
            this.btnMos.Name = "btnMos";
            this.btnMos.Size = new System.Drawing.Size(89, 32);
            this.btnMos.TabIndex = 12;
            this.btnMos.Text = "Mostrar tudo";
            this.btnMos.UseVisualStyleBackColor = true;
            this.btnMos.Click += new System.EventHandler(this.btnMos_Click);
            // 
            // btnEd
            // 
            this.btnEd.Location = new System.Drawing.Point(395, 99);
            this.btnEd.Name = "btnEd";
            this.btnEd.Size = new System.Drawing.Size(89, 32);
            this.btnEd.TabIndex = 11;
            this.btnEd.Text = "Editar";
            this.btnEd.UseVisualStyleBackColor = true;
            this.btnEd.Click += new System.EventHandler(this.btnEd_Click);
            // 
            // btnExc
            // 
            this.btnExc.Location = new System.Drawing.Point(277, 99);
            this.btnExc.Name = "btnExc";
            this.btnExc.Size = new System.Drawing.Size(89, 32);
            this.btnExc.TabIndex = 10;
            this.btnExc.Text = "Excluir";
            this.btnExc.UseVisualStyleBackColor = true;
            this.btnExc.Click += new System.EventHandler(this.btnExc_Click);
            // 
            // btnCons
            // 
            this.btnCons.Location = new System.Drawing.Point(159, 99);
            this.btnCons.Name = "btnCons";
            this.btnCons.Size = new System.Drawing.Size(89, 32);
            this.btnCons.TabIndex = 9;
            this.btnCons.Text = "Consultar";
            this.btnCons.UseVisualStyleBackColor = true;
            this.btnCons.Click += new System.EventHandler(this.btnCons_Click);
            // 
            // btnCad
            // 
            this.btnCad.Location = new System.Drawing.Point(41, 99);
            this.btnCad.Name = "btnCad";
            this.btnCad.Size = new System.Drawing.Size(89, 32);
            this.btnCad.TabIndex = 8;
            this.btnCad.Text = "Cadastrar";
            this.btnCad.UseVisualStyleBackColor = true;
            this.btnCad.Click += new System.EventHandler(this.btnCad_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightBlue;
            this.tabPage2.Controls.Add(this.dgv2);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtDESC);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtIDM);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(634, 328);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Modelos";
            // 
            // dgv2
            // 
            this.dgv2.AllowUserToAddRows = false;
            this.dgv2.AllowUserToDeleteRows = false;
            this.dgv2.AllowUserToResizeColumns = false;
            this.dgv2.AllowUserToResizeRows = false;
            this.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv2.Location = new System.Drawing.Point(93, 148);
            this.dgv2.Name = "dgv2";
            this.dgv2.Size = new System.Drawing.Size(440, 150);
            this.dgv2.TabIndex = 27;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(505, 94);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 32);
            this.button1.TabIndex = 26;
            this.button1.Text = "Mostrar tudo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(394, 94);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 32);
            this.button2.TabIndex = 25;
            this.button2.Text = "Editar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(276, 94);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(89, 32);
            this.button3.TabIndex = 24;
            this.button3.Text = "Excluir";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(158, 94);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 32);
            this.button4.TabIndex = 23;
            this.button4.Text = "Consultar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(40, 94);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(89, 32);
            this.button5.TabIndex = 22;
            this.button5.Text = "Cadastrar";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(264, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Descrição";
            // 
            // txtDESC
            // 
            this.txtDESC.Location = new System.Drawing.Point(264, 36);
            this.txtDESC.Name = "txtDESC";
            this.txtDESC.Size = new System.Drawing.Size(329, 20);
            this.txtDESC.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "ID";
            // 
            // txtIDM
            // 
            this.txtIDM.Location = new System.Drawing.Point(37, 36);
            this.txtIDM.Name = "txtIDM";
            this.txtIDM.Size = new System.Drawing.Size(89, 20);
            this.txtIDM.TabIndex = 15;
            // 
            // crud_rastreadores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 351);
            this.Controls.Add(this.Rastrador);
            this.Name = "crud_rastreadores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Rastrador.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Rastrador;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnMos;
        private System.Windows.Forms.Button btnEd;
        private System.Windows.Forms.Button btnExc;
        private System.Windows.Forms.Button btnCons;
        private System.Windows.Forms.Button btnCad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMOD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtIMEI;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtICCID;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.DataGridView dgv2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDESC;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIDM;
    }
}

