﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Registros
{

    public partial class crud_rastreadores : Form
    {
        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;

        public crud_rastreadores()
        {
            InitializeComponent();
        }


        private void btnCad_Click(object sender, EventArgs e)
        {
            dgv1.DataSource = null;
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL="INSERT INTO RASTREADORES (ICCID, IMEI, MODELO) VALUES (@ICCID, @IMEI, @MODELO)";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@ICCID", txtICCID.Text);
                comando.Parameters.AddWithValue("@IMEI", txtIMEI.Text);
                comando.Parameters.AddWithValue("@MODELO", txtMOD.Text);

                
                conexao.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Cadastro realizado! ", "Cadastro");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void btnEd_Click(object sender, EventArgs e)
        {
            dgv1.DataSource = null;
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "UPDATE RASTREADORES SET ICCID = @ICCID, IMEI = @IMEI, MODELO = @MODELO WHERE IDRASTREADORES = @IDRASTREADORES";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@IDRASTREADORES", txtID.Text);
                comando.Parameters.AddWithValue("@ICCID", txtICCID.Text);
                comando.Parameters.AddWithValue("@IMEI", txtIMEI.Text);
                comando.Parameters.AddWithValue("@MODELO", txtMOD.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Edição realizada! ", "Ediçao");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void btnExc_Click(object sender, EventArgs e)
        {
            dgv1.DataSource = null;
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "DELETE FROM RASTREADORES WHERE IDRASTREADORES = @IDRASTREADORES";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@IDRASTREADORES", txtID.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Exclusão realizada! ", "Exclusão");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void btnCons_Click(object sender, EventArgs e)
        {
            dgv1.DataSource = null;
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "SELECT * FROM RASTREADORES WHERE IDRASTREADORES = @IDRASTREADORES";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@IDRASTREADORES", txtID.Text);

                conexao.Open();

                dr = comando.ExecuteReader();

                while (dr.Read())
                {
                    MessageBox.Show("ID: " + Convert.ToString(txtID.Text) + "\nModelo: " + Convert.ToString(txtMOD.Text)
                        + "\nICCID: " + Convert.ToString(txtID.Text) + "\nIMEI: " + Convert.ToString(txtID.Text), "Consulta");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void btnMos_Click(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "SELECT * FROM RASTREADORES";

                da = new MySqlDataAdapter(strSQL, conexao);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgv1.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            dgv2.DataSource = null;
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "INSERT INTO MODELO (DESC) VALUES (@DESC)";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@DESC", txtDESC.Text);


                conexao.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Cadastro realizado! ", "Cadastro");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dgv2.DataSource = null;
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "SELECT * FROM MODELO WHERE IDMODELO= @IDMODELO";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@IDMODELO", txtIDM.Text);

                conexao.Open();

                dr = comando.ExecuteReader();

                while (dr.Read())
                {
                    MessageBox.Show("ID: " + Convert.ToString(txtIDM.Text) + "\nDescrição: " + Convert.ToString(txtDESC.Text), "Consulta");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dgv2.DataSource = null;
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "DELETE FROM MODELO WHERE IDMODELO = @IDMODELO";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@IDMODELO", txtIDM.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Exclusão realizada! ", "Exclusão");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dgv2.DataSource = null;
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "UPDATE MODELO SET DESC = @DESC WHERE IDMODELO = @IDMODELO";
                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@IDMODELO", txtIDM.Text);
                comando.Parameters.AddWithValue("@DESC", txtDESC.Text);

                conexao.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Edição realizada! ", "Ediçao");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server=localhost;Database=mydb;Uid=root;Pwd=1234;");
                strSQL = "SELECT * FROM MODELO";

                da = new MySqlDataAdapter(strSQL, conexao);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgv1.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                comando = null;
                comando = null;
            }
            ClearTextBoxes();
        }
    }
}
